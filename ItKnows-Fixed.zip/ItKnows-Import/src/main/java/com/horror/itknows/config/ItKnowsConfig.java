package com.horror.itknows.config;

import net.minecraftforge.common.ForgeConfigSpec;

public class ItKnowsConfig {
    public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.IntValue DAYS_BEFORE_START;
    public static final ForgeConfigSpec.IntValue SPAWN_CHANCE_PER_NIGHT;
    public static final ForgeConfigSpec.BooleanValue ENABLE_AMBIENT_EVENTS;
    public static final ForgeConfigSpec.BooleanValue ENABLE_TORCH_EXTINGUISH;
    public static final ForgeConfigSpec.BooleanValue ENABLE_WHISPERS;
    public static final ForgeConfigSpec.DoubleValue AGGRESSION_MULTIPLIER;

    static {
        BUILDER.push("It Knows Settings");

        DAYS_BEFORE_START = BUILDER
                .comment("How many full days before the horror begins (default: 2)")
                .defineInRange("daysBeforeStart", 2, 0, 30);

        SPAWN_CHANCE_PER_NIGHT = BUILDER
                .comment("Chance (1 in X) that The Watcher spawns each night after the start day")
                .defineInRange("spawnChancePerNight", 3, 1, 50);

        ENABLE_AMBIENT_EVENTS = BUILDER
                .comment("Enable random ambient horror events (footsteps, doors, etc.)")
                .define("enableAmbientEvents", true);

        ENABLE_TORCH_EXTINGUISH = BUILDER
                .comment("Allow torches/candles to randomly extinguish near the player")
                .define("enableTorchExtinguish", true);

        ENABLE_WHISPERS = BUILDER
                .comment("Enable creepy whisper messages in chat")
                .define("enableWhispers", true);

        AGGRESSION_MULTIPLIER = BUILDER
                .comment("How quickly aggression escalates (higher = faster)")
                .defineInRange("aggressionMultiplier", 1.0, 0.5, 3.0);

        BUILDER.pop();
        SPEC = BUILDER.build();
    }
}
