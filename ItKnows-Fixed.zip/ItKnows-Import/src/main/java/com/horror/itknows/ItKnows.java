package com.horror.itknows;

import com.horror.itknows.config.ItKnowsConfig;
import com.horror.itknows.entity.ModEntities;
import com.horror.itknows.entity.WatcherEntity;
import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(ItKnows.MOD_ID)
public class ItKnows {
    public static final String MOD_ID = "itknows";
    public static final Logger LOGGER = LogUtils.getLogger();

    public ItKnows() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModEntities.register(modEventBus);

        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::registerCapabilities);
        modEventBus.addListener(this::entityAttributes);

        // HorrorEvents is registered via @Mod.EventBusSubscriber

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, ItKnowsConfig.SPEC);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        LOGGER.info("It Knows has loaded. Something is watching...");
    }

    private void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.register(com.horror.itknows.capability.PlayerHorror.class);
    }

    private void entityAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.WATCHER.get(), WatcherEntity.createAttributes().build());
    }

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MOD_ID, path);
    }
}
