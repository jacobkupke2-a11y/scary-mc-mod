package com.horror.itknows.event;

import com.horror.itknows.ItKnows;
import com.horror.itknows.capability.PlayerHorror;
import com.horror.itknows.capability.PlayerHorrorProvider;
import com.horror.itknows.config.ItKnowsConfig;
import com.horror.itknows.entity.ModEntities;
import com.horror.itknows.entity.WatcherEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CandleBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.SleepFinishedTimeEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;
import java.util.Random;

@Mod.EventBusSubscriber(modid = ItKnows.MOD_ID)
public class HorrorEvents {
    private static final Random RANDOM = new Random();
    private static final String[] WHISPERS = {
            "I see you...",
            "You can't hide forever.",
            "I've been watching since the beginning.",
            "Do you feel me?",
            "Behind you.",
            "It knows where you sleep.",
            "Your light will go out.",
            "Don't turn around.",
            "I learn everything.",
            "Soon."
    };

    @SubscribeEvent
    public static void onAttachCapabilities(AttachCapabilitiesEvent<net.minecraft.world.entity.Entity> event) {
        if (event.getObject() instanceof Player) {
            if (!event.getObject().getCapability(PlayerHorrorProvider.PLAYER_HORROR).isPresent()) {
                event.addCapability(ItKnows.id("player_horror"), new PlayerHorrorProvider());
            }
        }
    }

    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        if (event.isWasDeath()) {
            event.getOriginal().reviveCaps();
            event.getOriginal().getCapability(PlayerHorrorProvider.PLAYER_HORROR).ifPresent(oldStore -> {
                event.getEntity().getCapability(PlayerHorrorProvider.PLAYER_HORROR).ifPresent(newStore -> {
                    newStore.copyFrom(oldStore);
                });
            });
            event.getOriginal().invalidateCaps();
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        if (player.level().isClientSide) return;

        player.getCapability(PlayerHorrorProvider.PLAYER_HORROR).ifPresent(horror -> {
            Level level = player.level();
            long dayTime = level.getDayTime() % 24000;
            int currentDay = (int) (level.getDayTime() / 24000L);

            // Update days survived
            if (currentDay > horror.getDaysSurvived()) {
                horror.setDaysSurvived(currentDay);
                horror.addAwareness(2); // Slow awareness growth
            }

            // Only start after configured days
            if (currentDay < ItKnowsConfig.DAYS_BEFORE_START.get()) return;

            // Night time events
            boolean isNight = dayTime > 13000 && dayTime < 23000;

            if (isNight && level.getGameTime() % 100 == 0) {
                trySpawnWatcher(player, horror, (ServerLevel) level);
            }

            // Ambient events
            if (ItKnowsConfig.ENABLE_AMBIENT_EVENTS.get() && level.getGameTime() % 200 == 0) {
                doAmbientEvent(player, horror, level);
            }
        });
    }

    private static void trySpawnWatcher(ServerPlayer player, PlayerHorror horror, ServerLevel level) {
        // Don't spawn if one already exists nearby
        AABB searchBox = player.getBoundingBox().inflate(80);
        List<WatcherEntity> existing = level.getEntitiesOfClass(WatcherEntity.class, searchBox);
        if (!existing.isEmpty()) return;

        if (RANDOM.nextInt(ItKnowsConfig.SPAWN_CHANCE_PER_NIGHT.get()) != 0) return;

        // Spawn at a distance, preferably behind or to the side
        double angle = RANDOM.nextDouble() * Math.PI * 2;
        double distance = 25 + RANDOM.nextDouble() * 20;
        double x = player.getX() + Math.cos(angle) * distance;
        double z = player.getZ() + Math.sin(angle) * distance;
        double y = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING,
                (int) x, (int) z);

        WatcherEntity watcher = ModEntities.WATCHER.get().create(level);
        if (watcher != null) {
            watcher.moveTo(x, y, z, 0, 0);
            // Stage based on awareness
            int stage = Math.min(3, horror.getAwareness() / 25);
            watcher.setStage(stage);
            level.addFreshEntity(watcher);
            horror.setHasEncountered(true);
            horror.addAwareness(5);

            // Subtle notification sometimes
            if (RANDOM.nextFloat() < 0.3f) {
                player.sendSystemMessage(Component.literal("§8You feel like you're being watched..."));
            }
        }
    }

    private static void doAmbientEvent(ServerPlayer player, PlayerHorror horror, Level level) {
        long now = level.getGameTime();
        if (now - horror.getLastEventTime() < 600) return; // Cooldown

        int roll = RANDOM.nextInt(100);
        int awareness = horror.getAwareness();

        if (roll < 15 && ItKnowsConfig.ENABLE_WHISPERS.get() && awareness > 10) {
            // Whisper
            String msg = WHISPERS[RANDOM.nextInt(WHISPERS.length)];
            player.sendSystemMessage(Component.literal("§8§o" + msg));
            horror.setLastEventTime(now);
            horror.addAwareness(1);
        } else if (roll < 30 && ItKnowsConfig.ENABLE_TORCH_EXTINGUISH.get() && awareness > 5) {
            // Extinguish nearby light
            extinguishNearbyLights(player, level);
            horror.setLastEventTime(now);
        } else if (roll < 45 && awareness > 15) {
            // Fake footsteps
            level.playSound(null, player.blockPosition().offset(
                    RANDOM.nextInt(7) - 3, 0, RANDOM.nextInt(7) - 3),
                    SoundEvents.WOOD_STEP, SoundSource.AMBIENT, 0.6f, 0.7f);
            horror.setLastEventTime(now);
        } else if (roll < 55 && awareness > 20) {
            // Cave ambient / creepy sound
            level.playSound(null, player.blockPosition(),
                    caveSound(), SoundSource.AMBIENT, 0.9f, 0.5f + RANDOM.nextFloat() * 0.3f);
            horror.setLastEventTime(now);
        }
    }

    private static net.minecraft.sounds.SoundEvent caveSound() {
        net.minecraft.sounds.SoundEvent s = net.minecraftforge.registries.ForgeRegistries.SOUND_EVENTS
                .getValue(new net.minecraft.resources.ResourceLocation("minecraft", "ambient.cave"));
        return s != null ? s : SoundEvents.ENDERMAN_STARE;
    }

    private static void extinguishNearbyLights(ServerPlayer player, Level level) {
        BlockPos playerPos = player.blockPosition();
        for (int x = -6; x <= 6; x++) {
            for (int y = -2; y <= 3; y++) {
                for (int z = -6; z <= 6; z++) {
                    BlockPos pos = playerPos.offset(x, y, z);
                    BlockState state = level.getBlockState(pos);
                    if (state.is(Blocks.TORCH) || state.is(Blocks.WALL_TORCH) ||
                            state.is(Blocks.SOUL_TORCH) || state.is(Blocks.SOUL_WALL_TORCH)) {
                        if (RANDOM.nextFloat() < 0.4f) {
                            level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                            level.playSound(null, pos, SoundEvents.FIRE_EXTINGUISH,
                                    SoundSource.BLOCKS, 0.5f, 1.0f);
                        }
                    } else if (state.getBlock() instanceof CandleBlock && state.getValue(CandleBlock.LIT)) {
                        if (RANDOM.nextFloat() < 0.5f) {
                            level.setBlock(pos, state.setValue(CandleBlock.LIT, false), 3);
                            level.playSound(null, pos, SoundEvents.CANDLE_EXTINGUISH,
                                    SoundSource.BLOCKS, 0.5f, 1.0f);
                        }
                    }
                }
            }
        }
    }

    @SubscribeEvent
    public static void onSleepFinished(SleepFinishedTimeEvent event) {
        // Small chance something is standing over the bed when you wake
        if (event.getLevel() instanceof ServerLevel serverLevel) {
            for (ServerPlayer player : serverLevel.players()) {
                player.getCapability(PlayerHorrorProvider.PLAYER_HORROR).ifPresent(horror -> {
                    if (horror.getAwareness() > 30 && RANDOM.nextFloat() < 0.15f) {
                        // Spawn watcher very close for a moment
                        WatcherEntity watcher = ModEntities.WATCHER.get().create(serverLevel);
                        if (watcher != null) {
                            watcher.moveTo(player.getX() + 1.5, player.getY(), player.getZ(), 0, 0);
                            watcher.setStage(2);
                            serverLevel.addFreshEntity(watcher);
                            player.sendSystemMessage(Component.literal("§4§oYou feel cold air on your neck..."));
                        }
                    }
                });
            }
        }
    }
}
