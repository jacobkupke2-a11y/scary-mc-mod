package com.horror.itknows.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class WatcherEntity extends Monster {
    private static final EntityDataAccessor<Boolean> HOSTILE =
            SynchedEntityData.defineId(WatcherEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> STAGE =
            SynchedEntityData.defineId(WatcherEntity.class, EntityDataSerializers.INT);

    private int stareTicks = 0;
    private int vanishTicks = 0;
    private Player targetPlayer = null;
    private boolean hasBeenSeen = false;

    public WatcherEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 100.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.ATTACK_DAMAGE, 12.0D)
                .add(Attributes.FOLLOW_RANGE, 80.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.8D)
                .add(Attributes.ARMOR, 6.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(HOSTILE, false);
        this.entityData.define(STAGE, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.3D, true) {
            @Override
            public boolean canUse() {
                return isHostileMode() && super.canUse();
            }
        });
        this.goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 64.0F));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void tick() {
        super.tick();

        if (this.level().isClientSide) return;

        // Find nearest player
        Player nearest = this.level().getNearestPlayer(this, 64.0D);
        if (nearest == null || !nearest.isAlive()) {
            this.discard();
            return;
        }

        targetPlayer = nearest;
        double dist = this.distanceTo(nearest);

        // Check if player is looking at us
        boolean beingLookedAt = isPlayerLookingAt(nearest);

        if (isHostileMode()) {
            // Aggressive mode - chase and attack
            this.getNavigation().moveTo(nearest, 1.35D);
            if (dist < 2.5D) {
                this.doHurtTarget(nearest);
            }
            return;
        }

        // Passive watching mode
        if (beingLookedAt) {
            stareTicks++;
            hasBeenSeen = true;

            // If stared at too long, either vanish or go aggressive depending on stage
            if (stareTicks > 40 + (getStage() * 20)) {
                if (getStage() >= 2 || this.random.nextFloat() < 0.35f) {
                    setHostileMode(true);
                    this.level().playSound(null, this.blockPosition(), SoundEvents.WARDEN_SONIC_BOOM,
                            SoundSource.HOSTILE, 0.6f, 0.5f);
                } else {
                    // Vanish
                    vanish();
                }
            }
        } else {
            stareTicks = 0;

            // Move closer when not being looked at (Weeping Angel style)
            if (dist > 8.0D) {
                Vec3 direction = nearest.position().subtract(this.position()).normalize();
                this.setPos(this.getX() + direction.x * 0.45,
                        this.getY() + direction.y * 0.1,
                        this.getZ() + direction.z * 0.45);
            } else if (dist > 3.5D) {
                this.getNavigation().moveTo(nearest, 0.9D);
            }

            // Chance to make creepy sound
            if (this.random.nextInt(200) == 0) {
                this.level().playSound(null, this.blockPosition(), CAVE_SOUND(),
                        SoundSource.AMBIENT, 0.8f, 0.4f + this.random.nextFloat() * 0.3f);
            }
        }

        // Auto vanish after long time if not aggressive
        if (hasBeenSeen && !isHostileMode() && this.tickCount > 1200) {
            vanish();
        }
    }

    private static SoundEvent CAVE_SOUND() {
        SoundEvent s = net.minecraftforge.registries.ForgeRegistries.SOUND_EVENTS
                .getValue(new net.minecraft.resources.ResourceLocation("minecraft", "ambient.cave"));
        return s != null ? s : SoundEvents.ENDERMAN_STARE;
    }

    private boolean isPlayerLookingAt(Player player) {
        Vec3 look = player.getViewVector(1.0F).normalize();
        Vec3 toEntity = this.position().add(0, this.getEyeHeight(), 0)
                .subtract(player.getEyePosition()).normalize();
        double dot = look.dot(toEntity);
        return dot > 0.92D && player.hasLineOfSight(this);
    }

    private void vanish() {
        this.level().playSound(null, this.blockPosition(), SoundEvents.ENDERMAN_TELEPORT,
                SoundSource.HOSTILE, 0.7f, 0.6f);
        this.discard();
    }

    public boolean isHostileMode() {
        return this.entityData.get(HOSTILE);
    }

    public void setHostileMode(boolean value) {
        this.entityData.set(HOSTILE, value);
    }

    public int getStage() {
        return this.entityData.get(STAGE);
    }

    public void setStage(int stage) {
        this.entityData.set(STAGE, Math.min(stage, 3));
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!isHostileMode()) {
            setHostileMode(true);
        }
        return super.hurt(source, amount);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Aggressive", isHostileMode());
        tag.putInt("Stage", getStage());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setHostileMode(tag.getBoolean("Aggressive"));
        setStage(tag.getInt("Stage"));
    }

    @Override
    protected boolean shouldDespawnInPeaceful() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return null; // Silent by default
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.WARDEN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.WARDEN_DEATH;
    }
}
