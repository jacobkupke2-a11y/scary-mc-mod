package com.horror.itknows.capability;

import net.minecraft.nbt.CompoundTag;

public class PlayerHorror {
    private int awareness = 0;          // 0-100 how much "it" knows about you
    private int daysSurvived = 0;
    private long lastEventTime = 0;
    private boolean hasEncountered = false;

    public int getAwareness() {
        return awareness;
    }

    public void setAwareness(int value) {
        this.awareness = Math.max(0, Math.min(100, value));
    }

    public void addAwareness(int amount) {
        setAwareness(this.awareness + amount);
    }

    public int getDaysSurvived() {
        return daysSurvived;
    }

    public void setDaysSurvived(int days) {
        this.daysSurvived = days;
    }

    public void incrementDays() {
        this.daysSurvived++;
    }

    public long getLastEventTime() {
        return lastEventTime;
    }

    public void setLastEventTime(long time) {
        this.lastEventTime = time;
    }

    public boolean hasEncountered() {
        return hasEncountered;
    }

    public void setHasEncountered(boolean value) {
        this.hasEncountered = value;
    }

    public void saveNBT(CompoundTag tag) {
        tag.putInt("Awareness", awareness);
        tag.putInt("DaysSurvived", daysSurvived);
        tag.putLong("LastEventTime", lastEventTime);
        tag.putBoolean("HasEncountered", hasEncountered);
    }

    public void loadNBT(CompoundTag tag) {
        awareness = tag.getInt("Awareness");
        daysSurvived = tag.getInt("DaysSurvived");
        lastEventTime = tag.getLong("LastEventTime");
        hasEncountered = tag.getBoolean("HasEncountered");
    }

    public void copyFrom(PlayerHorror source) {
        this.awareness = source.awareness;
        this.daysSurvived = source.daysSurvived;
        this.lastEventTime = source.lastEventTime;
        this.hasEncountered = source.hasEncountered;
    }
}
