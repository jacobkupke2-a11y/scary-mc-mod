package com.horror.itknows.entity;

import com.horror.itknows.ItKnows;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ItKnows.MOD_ID);

    public static final RegistryObject<EntityType<WatcherEntity>> WATCHER =
            ENTITY_TYPES.register("watcher",
                    () -> EntityType.Builder.of(WatcherEntity::new, MobCategory.MONSTER)
                            .sized(0.6f, 1.95f)
                            .clientTrackingRange(64)
                            .updateInterval(1)
                            .build("watcher"));

    public static void register(IEventBus eventBus) {
        ENTITY_TYPES.register(eventBus);
    }
}
