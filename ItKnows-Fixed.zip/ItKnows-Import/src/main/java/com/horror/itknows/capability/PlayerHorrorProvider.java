package com.horror.itknows.capability;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.util.INBTSerializable;
import net.minecraftforge.common.util.LazyOptional;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PlayerHorrorProvider implements ICapabilityProvider, INBTSerializable<CompoundTag> {
    public static final Capability<PlayerHorror> PLAYER_HORROR =
            CapabilityManager.get(new CapabilityToken<>() {});

    private PlayerHorror horror = null;
    private final LazyOptional<PlayerHorror> optional = LazyOptional.of(this::createPlayerHorror);

    private PlayerHorror createPlayerHorror() {
        if (this.horror == null) {
            this.horror = new PlayerHorror();
        }
        return this.horror;
    }

    @Override
    public @NotNull <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == PLAYER_HORROR) {
            return optional.cast();
        }
        return LazyOptional.empty();
    }

    @Override
    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        createPlayerHorror().saveNBT(tag);
        return tag;
    }

    @Override
    public void deserializeNBT(CompoundTag tag) {
        createPlayerHorror().loadNBT(tag);
    }
}
